# CODEX IMPLEMENTATION CONTRACT — FINAL DUAL-BRANCH PASTURE STUDY

**Contract ID:** `DUAL-JEPA-DINO-2026-10-09-r1`  
**Status:** BUILD SPECIFICATION ONLY. No patched Kaggle notebook, trained model, Kaggle job, or journal acceptance is claimed by this document.  
**User-selected implementer:** Codex. **Independent verifier:** GPT-6 Medium, operating in a separate review pass.  
**Source baseline:** uploaded `capstone_v20.ipynb` SHA256 `4d2f7ef85d89c26fff489e6848063927262662f74ff053d1839f16784f93a355`; project `RaphaelBlaster/Img2BioMass` must be pinned to a recorded exact commit, not an unverified working-tree branch.  
**Prior planning document:** `FINAL_TWO_BRANCH_KAGGLE_RESEARCH_PLAN.md`; this implementation contract takes precedence wherever more precise or conflicting.  
**Deadline:** User requests immediate execution planning ahead of October 10, 2026. Prioritize complete, truthful matched results, not maximal number of experiments. No unsupervised jobs are to be launched by merely reading this document.

## 0. The task is TWO independent methods IN ONE Kaggle notebook

Scientific hypothesis **H1:** additional *predictor-only* I-JEPA latent training on within-parent-image 10×10 jigsaw permutations improves unshuffled-image biomass regression against the exact equal-update unshuffled predictor-training control.

Scientific hypothesis **H2:** DINOv3 pretrained dense patch representations with learned **area-integrated local component-density regression** perform differently from a matched conventional global-pooled DINOv3 head.

Scientific hypothesis **H3:** a **nontrivial cross-scale consistency penalty** improves the DINOv3 local-density model at identical inference resolution and parameter count.

**Interpretation rule:** a nonsignificant or negative result is publishable evidence if reported accurately; neither paper acceptance nor superiority is promised. DINOv3 is not I-JEPA; its ordinary dense features are a control/alternative. This is **not** a DINOv3+iBOT self-supervised retraining experiment.

### Three nonnegotiable provenance facts

1. Official Meta I-JEPA ViT-H/14 original paired weights: `size=224`, `patch_size=14`, `grid=16×16`, encoder token dim 1280, predictor depth 12, predictor internal width 384; predictor output returns **1280-dimensional latents** after its output projection. Official collator: one encoder mask, four target masks with `enc_mask_scale=(.85,1.)`, `pred_mask_scale=(.15,.2)`, aspect ratio `(0.75,1.5)`, and no encoder/target overlap.
2. Completed grass-domain checkpoint should contain `encoder`, `predictor`, `target_encoder`, `step=2400`, `domain_adaptation_status='completed_steps'`, official revision `52c1ae95d05f743e000e8f10a1f3a79b10cff048`; use the **actual saved checkpoint**, do not reconstruct it or substitute a different one silently. The audited external SSL data count is 30,663. This Stage 1 is **already completed and must be reused**.
3. Meta DINOv3 ViT-B/16 is a **separate** pretrained 768-dim/16-pixel-patch model with CLS + register + spatial patch tokens; at 512×512 the **spatial** sequence contains 32×32 = 1,024 tokens. The matching *official* DINOv3 ViT-B/16 checkpoint and library must be available OFFLINE with exact hash. Do not load `torchvision` ViT-B weights and label them DINOv3.

## 1. Immutable inputs and baseline inspection

Before changing code, create `final_dual_study/provenance/SOURCE_BASELINE.json` recording hash and location of: (a) original notebook, (b) current Git commit and dirty-file status, (c) existing original official source and adapted checkpoint, (d) DINOv3 checkpoint and model source, (e) CSIRO labeled CSV and its fold CSV, (f) GrassClover manifest; annotate every missing item. Never use a file inferred from a filename without loading/validating it.

Read `AGENTS.md`, `GOAL.md`, and **the latest** `CURRENT_STATUS.md` if present in the actual Codex workspace; uploaded markdown snapshot warns that unpublished work may not be in Git. Source control only documents a version, not whether that version was run successfully. Preserve old notebook versions and historical selected checkpoints. No touching private credentials.

Verify the labeled table contains exactly 357 unique original image paths (if supplied data differ, STOP and audit), exact five targets in order `Dry_Green_g`, `Dry_Dead_g`, `Dry_Clover_g`, `GDM_g`, `Dry_Total_g`, and `WEIGHTS=(.1,.1,.1,.2,.5)`. A `Sampling_Date` group must not cross folds. Use original folds **0 and 1** for the primary bounded run; prior results on these 105 images have already been reused in development, so **not** protected validation.

Check `GDM ≈ Green + Clover` tolerance .15g (an enforced data invariant) and quantify rather than overwrite any discrepancies in `Total ≈ GDM + Dead`. Use the verified matched head's 3 nonnegative primitives and derived sums for all comparison arms unless predeclared otherwise. Never silently introduce independent five-output target regression.

**Mandatory hard stops:** missing or corrupt Stage-1 weights; missing DINOv3 offline weights for a study labelled *complete two-branch*; Kaggle GPU quota insufficient for all predeclared primary comparisons; unknown image/fold provenance; or failed mask/gradient/leakage smoke test. Record blockers, preserve completed artifacts, mark the study `INCOMPLETE`, and never fill missing results with historical scores.

## 2. Files Codex MUST build (not present by magic)

Keep the original v20 notebook unchanged and create `capstone_FINAL_DUAL_JEPA_DINO.ipynb` with a rebuilt, embedded, versioned package ZIP. Add/test:

| New module | Required responsibility | Existing code to reuse |
|---|---|---|
| `biomass_jepa/within_image_jigsaw.py` | Native 10×10 within-image permutation, 10 distinct variants, parent manifests | Existing `block_shuffle.py` utility, after audit |
| `biomass_jepa/predictor_specialize.py` | Fold-filtered predictor-only JEPA training, matched arm scheduler, resumable state | `official_train.StrictOfficialCollator`; `official_ijepa.ssl_latents` |
| `biomass_jepa/semantic_predictor_features.py` | New fixed four-block JEPA readout **without half-mask function** | Official encoder/predictor, `validate_ssl_masks` |
| `biomass_jepa/final_head.py` | Fold/arm-specific cached feature head training with 200 epochs + final-40 SWA | Current `official_heads.GatedRegressionHead` (not in v20 ZIP) |
| `biomass_jepa/dinov3_dense.py` | Authenticated OFFLINE ViT-B loading, spatial-only 512 token extraction, 8×8 cache, D0/D1/D2 heads | DINOv3 reference, pinned |
| `biomass_jepa/final_metrics.py` | Independent pooled raw weighted R², per-target errors, date-group paired bootstrap | `metrics.scores` cross-check |
| `biomass_jepa/final_figures.py` | Publication figures from saved measurements, not invented diagrams claiming data | matplotlib |
| `tests/test_final_dual.py` | Shape, gradient, leakage, objective/degeneracy, save/reload, metric, resume tests | Reuse synthetic tiny-model tests |

**Do not** run old v20 cell(s) that repeat 30K SSL or its old `finetune`. **Do not** call `official_heads.fit_heads()` as-is: the checked repository implementation accepts only fold lists `[0,1]` or `[0,1,2]`, assumes a single shared source representation, and the predictor cache invokes the legacy `OfficialBiomassModel.patch_predictions()` half-mask readout. Implement a **new fold-specific feature-cache head runner** that uses the same gated head and weighted loss, not a silent change to those old functions. Note the old `regression_factory` rejects independent-targets/alternative predictor-readouts; use a new class.

One notebook ≠ one intermingled model: the J and D branches must use separate module namespaces, output directories, dataloaders, heads, state/signature checks, and precision declarations.

## 3. Shared image processing — full coverage and no fictional labels

Each full CSIRO image is 2000×1000 (verify after EXIF transpose). Split into two **nonoverlapping** 1000×1000 PIL RGB square views that cover the complete field exactly. Each original has ONE biological label row. Do not assign that full label to individual views/bins as if independently measured. Stage J resizes each view to 224×224; stage D resizes each view to 512×512. Fix interpolation (`PIL.Image.Resampling.BICUBIC` or exactly the verified prior `torchvision.Resize` choice), antialiasing, ImageNet RGB normalization, and EXIF handling in source and manifest; no cross-branch accidental reuse of already-resized 224 data.

The ten jigsaw variations per *native* 1000×1000 view: divide into 100 100×100 pixel cells, generate ten **distinct** nonidentity bijections of cell positions, and reassemble each cell once. No crop, blending, smoothing, overlap, loss of pixels, or blocks from other photos. Shuffle before 224 resizing. Deterministic seed `SHA256(image SHA | view ID | permutation index | master seed)`; store actual index arrays, not just seed. A permutation is an augmentation, **not** a separate independent labeled observation. All variants inherit parent image/fold/group. Prove byte-exact conservation of pixel multiset **before interpolation**, for RGB and a synthetic unique-pixel sentinel.

A potential biological weakness must be disclosed: seams and disrupted texture/plant morphology can hurt I-JEPA. Do not claim jigsaws are “more real biomass images.”

## 4. Branch J: actual I-JEPA + predictor-only specialization

### J1 — Reuse existing 30K checkpoint, do NOT retrain

Load the explicit `adapted.pt` with `torch.load(...,weights_only=True,map_location='cpu')`. Validate the Stage-1 metadata and strict state loading; record source SHA256. The three named modules are **student/context encoder** `encoder`, **EMA target encoder** `target_encoder`, and **pretrained JEPA predictor** `predictor`. If the source is an original official full checkpoint with `module.` prefixes, use the checked `strip_ddp`; adapted exports use their own saved naming conventions and should load using `strict=True` with the appropriate loader. Source and adapted models must not be confused.

### J2 — Two matched, independent predictor-only arms **per fold**

For `f in [0,1]`, Stage-2 parents are **only** originals with `fold != f`, not held-out images. Images are used as unlabeled pixels; targets (grams) are not consumed in this stage. Original images in excluded validation fold must not be used through a different resize, permutation, source cache or Stage-2 latent teacher target. Warn if near-duplicate overlap with the 30K unlabeled corpus cannot be ruled out.

Initialize predictor of both arms from **identical bytes** of J1 for that fold. `control`: 20 unsupervised exposure slots per each 1000-square view, all original. `shuffle`: exactly 20 matched slots, 10 original + 10 different shuffles. Both arms use the same parent/source schedule, same total effective microbatches, same mask seed per slot and optimizer steps. **Materialize a mask-index schedule keyed by parent/view/exposure slot/fold before either run; do NOT assume that two separately launched `MaskCollator` dataloaders with persistent workers will consume the same masks.** It is acceptable for control to revisit the same image more often: that is precisely the no-jigsaw control. Preserve pairing independent of dataloader worker scheduling by generating the deterministic slot manifest first.

**Trainable:** predictor ONLY. **Frozen:** student encoder AND EMA teacher, including LayerNorm and buffers; both stay `eval()`. Never EMA-update the target if student frozen. `requires_grad=False` for both. Compute `teacher(images)` and `encoder(images,context_masks)` under `torch.no_grad()`. Compute `predictor(contexts, context_masks,target_masks)` with gradients enabled. Standard official teacher target = `F.layer_norm(teacher(images),(1280,))` then target `apply_masks` and official repeat ordering. Target and prediction tensors must match exactly in shape and ordering; no post-hoc masking of *student* full-image features. Use official `StrictOfficialCollator(size=224,patch_size=14)`, one context and four 15–20%-area target blocks. Validate no context-target overlap for every sample. Loss `F.smooth_l1_loss(pred.float(), target.float())`. Use FP32 for loss reductions.

Initial **nonvalidated proposal** (freeze before launch): AdamW predictor LR 1e-5, WD 0.04, grad clip 1, batch 8/accumulate 4 (effective 32), 20-update warmup then cosine. Calculate total steps from **complete** 20-slot schedule: `N = ceil(2 * n_train_parents * 20 / 32)` (2 views per parent). Handle partial last effective batch with sample-weighted accumulation; do not stop at an arbitrary 300 if that leaves unused variations. Budget J0/J1/arms/folds using observed timing, not guessed duration. If schedule infeasible, redesign **both arms equally before launch** and update the locked spec and reviewer; do not silently change only the treatment.

**Critical gradient smoke:** after two optimizer steps predictor parameters MUST change and have finite, nonzero relevant gradients; encoder and teacher weights AND buffers must remain bitwise equal to initial values, gradient fields absent. Predictor dropout/training stochasticity allowed if explicitly logged; all runs use the same prescribed seed schedule and model-state initialization. Save optimizer, schedule, epoch/cursor/slot, masks/collator RNG, Torch/CUDA/Python/NumPy RNG, current predictor tensor state, config and hashes; issue resume parity warning if worker randomness prevents exact replay (do not falsely claim bitwise reproducibility).

### J3 — Predicted-latent regression, NOT the historical half-mask head

Build `SemanticPredictorReadout` using **four fixed nonoverlapping target rectangles** on the **16×16 token grid**, each 6×7 = 42 patches (16.4% per rectangle, aspect 6/7 or 7/6 in the official range). One reproducible, shared mask set is sufficient; position four rectangles near the corners so all lie inside 16×16 and **no context patch is a target**. In concrete index form:

- T1: rows 0..5, columns 0..6
- T2: rows 0..5, columns 9..15
- T3: rows 10..15, columns 0..6
- T4: rows 10..15, columns 9..15
- Context: sorted complement of union(T1..T4); 88 visible patches.

Each target mask has exactly 42 tokens; context has 88. Call `encoder(images,[context_mask])`, then `predictor(context,[context_mask],[T1,T2,T3,T4])`. Confirm expected predictor output shape `[4 * (batch * views), 42, 1280]` **in the reference implementation's target-major, batch-minor order**; explicitly reshape `[4, B*views, 42, 1280]`, then mean over mask axis and target-token axis to obtain `[B*views,1280]`, reshape to `[B,2,1280]`. Verify actual reference ordering with a sentinel test; never rely only on shape. **Do not assume concatenation order** and do not use the current `complementary_patch_masks` path; check `repeat_interleave_batch` reference. Pool **all four target prediction blocks** into one 1280-d feature per view and preserve original view order. Validation and final inference always on original unshuffled photographs. Use exactly the same mask set/aggregation for J-control and J-shuffle.

Train a fold/arm-specific `GatedRegressionHead(dim=1280, width=512, dropout=.2)` on `[B,2,1280]` frozen predicted features; raw all-five weighted MSE divided by **training-only** target scale²; positive 3 primitives, GDM and Total as sums; optimizer AdamW LR 3e-4, WD .01, 200 epochs, cosine schedule, final 40 SWA. `selected.pt` uses fixed final SWA (not maximum validation epoch). Reuse the current checked `official_heads.py` precisely for head architecture and loss, except replacing source-specific feature cache loading. Epoch seed 42+fold; deterministic head initialization **identical across J-control and J-shuffle on the same fold**, and matched training example/order/rotation exposure. If replicating the existing head rotation recipe, cache precisely four pixel-exact quarter turns (0/90/180/270) of full square tiles in each arm, train with identical rotation schedules, and validate at orientation 0 only; do not introduce flips or photometric shifts. First backward can have **zero upstream gradient** because current head zeros last-layer weights; do not fail until after at least one optimizer update. Save fold-specific specialized predictor and regression head together with explicit hashes, plus all OOF predictions.

Record J stage-2 held-out **unshuffled** JEPA latent-prediction Smooth L1/cosine at fixed masks and non-leaking evaluation; these are diagnostics, not biomass metrics. J-control versus J-shuffle delta is the **causal experiment**; previous half-mask 0.5722 is only historical background.

## 5. Branch D: genuine DINOv3 pretrained ViT-B/16 + matched dense biomass heads

**Important:** DINOv3 is pretrained on its own objective; its backbone is **frozen** here. There is no iBOT head retraining, no JEPA-style predictor, and no blending its weights with I-JEPA. An official pretrained backbone + novel downstream controlled objective is a legitimate experiment, but **novelty is not asserted** without literature review.

Strictly load official DINOv3 ViT-B/16 from a pinned offline package/weights and log repo commit, license, SHA256. Use exactly two complete square views, each resized/normalized to 512×512. Extract `forward_features(...)["x_norm_patchtokens"]` (or verified equivalent). **NEVER** reshape CLS/register tokens as patches. Assert `[B*2, 1024, 768]` then reshape `[B,2,32,32,768]` and pool square patches to `[B,2,8,8,768]` (each pooled region covers 4×4 patch tokens); pool to `[B,2,4,4,768]` by 2×2 mean over the 8×8 grid. Cache features from all originals with checksum/source/preprocessing/shape manifests; these are image features only and may be cached for all rows before folding because the DINO backbone is frozen and no supervised labels enter its encoding. **Heads must train on fold!=f labels only**.

### Three DINO heads, same original images/folds and raw metric loss

**D0 GLOBAL**: mean of all 8×8 patch-grid features over both views → `[B,768]`; MLP/LN/softplus to three image-level primitive grams, GDM and Total derived. Standard global-pooling control. Fixed-head training, 200 epochs/final-40 SWA as below.

**D1 AREA-INTEGRATED**: an identical shared `density_head: 768 → 256 → 3` applied to each of the **128** (two views × 8×8 cells) local embeddings, with output `softplus` scaled by **training-fold-only** gram normalization. Image primitive grams = **equal-area mean over 128 region predictions** (each equally sized cell represents 1/128 of the photographed image). This is an image-level learned density proxy in *gram-equivalent* units, **not** measured biomass in any cell. Apply supervised MSE to the **image-level aggregated five targets only**, never the global label independently to each cell. Train only the head.

**D2 CROSS-SCALE**: architecture and primary 8×8 inference prediction are **identical to D1**. Additionally form the 4×4 coarser grid as an **average of neighboring embeddings BEFORE the nonlinear shared `density_head`**, predict coarse image grams by equal-area mean of the 32 coarse cells, and add penalty

`L_D1 = raw_weighted_MSE(y, pred_8) / train_scale²`

`L_D2 = L_D1 + λ * mean((pred_8[:,:3] - pred_4[:,:3])²) / train_scale²` with **predeclared `λ = 0.10`**, no validation tuning. D2 outputs the **same `pred_8` at inference** as D1. With nonlinear density head, `mean(h(mean(tokens))) != mean(h(tokens))` in general, so penalty is not a mathematical identity. **MANDATORY nondegeneracy test** on heterogeneous synthetic token grids: cross-scale penalty `> 1e-8` AND gradient contribution from penalty nonzero; otherwise redesign before training, never report it as a meaningful new objective. Store both `pred_8` and `pred_4` for diagnostic plots. This tests the *consistency regularizer alone*, not a larger D2 model.

Use matching D1/D2 parameter initialization, optimizer steps, folds, head seeds, order and training schedule. D0 is a separate baseline architecture. For D0/D1/D2 use same all-five gram-weighted raw loss, training-fold-only scale, 200 epochs, final 40 SWA, same folds 0/1, AdamW LR 3e-4/WD .01, batch 32 if feasible. Architectures have different inductive biases and potentially capacity; include trainable parameter counts. D2 λ choice must be labelled a prespecified hypothesis, not “optimal”.

**Critical DINO science guard:** simple linear per-cell heads or pooling after the same pointwise linear model make D1/D2 almost algebraically equivalent, destroying H3. Local nonlinear inference must be real, and reviewer must validate its numeric difference and gradient. Because the images have only *whole-field* labels, avoid interpreting spatial contribution heatmaps as actual biomass ground truth or segmentation.

## 6. Metric, inference and uncertainty — one locked implementation

Primary `R²_global = 1 - Σ_iΣ_t w_t(y_it - pred_it)² / Σ_iΣ_t w_t(y_it - μ)²`, `μ = (Σ_iΣ_t w_t y_it)/(N Σ_t w_t)`, `w=(.1,.1,.1,.2,.5)`. **One global mean across all targets**, not five denominators averaged and not per-fold means. Independently rescore all saved OOF CSV rows using an implementation written without importing existing project scoring helpers, compare to `biomass_jepa.metrics.scores` to tolerance `1e-10` on FP64 loaded predictions. Report per-target R², MAE, RMSE, bias, training/validation image counts, folds, date-group counts, model parameters, elapsed seconds/steps, GPU peak memory, checkpoint ID and precision.

A comparison is paired ONLY if original `image_path`, `Sampling_Date`, fold, labels and row identities match. For `J_shuffle - J_control`, `D1 - D0`, `D2 - D1`, use **10,000 fixed-seed** resamples of the 9 date groups with replacement, concat all member rows with multiplicity, recompute metric *difference* and save percentile 95% CI (and diagnostics for invalid denominator draws). This is only uncertainty conditional on selected trained models and repeatedly-used groups, not generalization or seed variability. Distinguish development 105/357 from historical full OOF; never compare raw global R² across different fold populations as causal evidence. Report per-target separate errors without asserting per-patch truth.

At inference every input is **unshuffled**; this is a preregistered distribution choice. If publishing the DINO branch as a fair backbone comparison, do **not** claim JEPA-vs-DINO superiority is isolated: J uses 224 and adapted JEPA, D uses 512 and pretrained DINO, with different heads/compute. Treat it as a methods comparison, not controlled pretraining comparison.

## 7. Kaggle notebook execution and persistent outputs

**Cells, strictly ordered:** (0) contract ID/config and source hashes; (1) offline dependency/wheels and package extraction; (2) weights/dataset/fold manifests; (3) static + tiny unit tests; (4) actual 1–2 GPU batches end-to-end J and D, independently sampled masks, nondegenerate penalty; (5) benchmark and **fresh** quota/session feasibility; (6) fold0 J-control J2/J3 complete; (7) fold0 J-shuffle J2/J3 complete; (8) fold1 J-control complete; (9) fold1 J-shuffle complete; (10) DINO cache; (11) fold0/1 D0,D1,D2 heads; (12) independent metrics/figures; (13) integrity verifier bundle and durable Kaggle Quick Save. All run blocks write atomically, status `prepared/running/completed/incomplete`, and refuse incompatible signature/resume rather than overwriting outputs. Keep at least two separate durable checkpoints for long J2 predictor training (`latest` and `completed`). No old v20 adaptation or old finetuning cell executed.

**Preflight must measure** time per stage-2 actual optimizer update, image cache step, DINO feature extraction, DINO head epoch, disk, VRAM and checkpoint serialization, then estimate total planned cost plus 20% safety margin; never trust historical quota snapshot. If BOTH J matched arms/folds and all D comparison heads cannot fit, Codex must STOP and report infeasible rather than claim combined study complete. A documented partial J-only result may be possible only after user explicitly re-scopes the contract; not automatic.

**Kaggle input restrictions:** disable internet at runtime; all checkpoints and wheels attached as versioned input datasets, no API secrets printed, verify SHA256. No auto-dispatch or silent paid fallback. Kaggle output folder should be writable and saved via “Quick Save / Always save output” after actual file existence and hash checks. Do not claim saved notebook artifacts merely from a successful cell.

**Required output directory** (may contain additional helper files but MUST contain these):

```text
final_dual_study/
  provenance/{SOURCE_BASELINE.json,CONFIG_LOCK.json,folds.csv,inputs_sha256.json,leakage_audit.json,environment.json,source_manifest.json}
  verifier/{implementation_diff.md,requirement_trace.csv,tiny_tests.json,gpu_smoke.json,resource_gate.json,INDEPENDENT_REVIEW_REQUEST.json}
  jepa/stage1_reused.json
  jepa/fold_0/{control,shuffle}/{predictor_specialized.pt,latest.pt,ssl_training.csv,features_manifest.json,head_selected.pt,head_training.csv,val_predictions.csv,metrics.json}
  jepa/fold_1/{control,shuffle}/...
  jepa/paired_oof.csv
  dinov3/checkpoint.json
  dinov3/cache_manifest.json
  dinov3/fold_0/{D0,D1,D2}/{head_selected.pt,head_training.csv,val_predictions.csv,metrics.json}
  dinov3/fold_1/{D0,D1,D2}/...
  dinov3/paired_oof.csv
  stats/{main_results.csv,per_target.csv,paired_bootstrap.csv,compute.csv}
  figure_data/*.csv
  figures/{study_design.png,jigsaw_native_and_224.png,jepa_latent_training.png,jepa_predictions.png,dino_scale_discrepancy.png,main_comparisons.png,per_target_residuals.png}
  VERIFIED_FILES_SHA256.json
  STATUS.json
  FINAL_REPORT.md
```

A *completed* paired result requires two fully trained fold models for both arms and exactly one prediction per held-out **original** image for both, with **identical 105 original IDs**. D requires the same per D0/D1/D2. Images and prediction CSVs are original biological observations, not ten synthetic rows per parent.

Figures must be generated using actual saved arrays; no fake smooth training curves, invented heatmaps or pseudo-ground truth. For original vs shuffled panels save parent ID, permutation array, and annotate that shuffles are artificial. For DINO region heatmaps label “model-inferred contribution proxy, unvalidated spatial localization.”

## 8. Implementation readiness gates — BEFORE asking Kaggle to run

**READY only if ALL are true:** (i) named source functions and CLI actually exist (no invented flags); (ii) synthetic unique-pixel permutation check passes; (iii) fold train/val parent exclusion passes; (iv) official mask geometry and target-order tests pass; (v) predictor-only update and frozen encoder+EMA immutability pass; (vi) J3 reload truly consumes J2 specialized predictor and no half-mask path; (vii) DINO spatial token removal and both-grid features correct; (viii) D2 consistency is nonzero/nontrivial; (ix) head save/reload and metric independent parity pass; (x) dataset/checkpoints/permissions/quota/output paths verified; (xi) Kaggle full-path smoke test succeeds without side-effecting final result directories; (xii) independent verifier returns **PASS** against the companion verifier protocol. Any deviation is a blocker pending explicit change approval; don't label adaptation as faithfully implemented just because the notebook executes.

## 9. Scientific Reports paper evidence and disclosures

Record predeclared H1/H2/H3, code/checkpoint/dataset citations, precise split grouping and reused-development caveats, hardware/precision, seed count, loss and head details, effective independent N=105 for primary comparison, paired bootstrap interval and failure cases. Distinguish scientific publication from Kaggle competition ranking. Cite **Meta I-JEPA**, **Meta DINOv3**, and **Arystanova et al., 2026, Agriculture 16:1401 (doi:10.3390/agriculture16131401)** in related work; do not call standard jigsaws, patch-mean pooling, or additive biomass sums inherently novel. DINOv3 license and I-JEPA weight licenses, GrassClover dataset rights, code/data availability, trained weights redistribution and use of AI tools must be verified before submission. **No result or journal acceptance is guaranteed.**

### Sources / audit anchors

- Local v20 `official_ijepa.py`: `OfficialEncoder`, `ssl_latents`, `validate_ssl_masks`, `OfficialBiomassModel.patch_predictions`, `regression_factory`; `official_train.py`: `StrictOfficialCollator`, `export`, `adapt`.
- Repo `biomass_jepa/official_heads.py`: `source_model`, `cache_features`, `GatedRegressionHead`, `fit_heads`, `FrozenHeadInference` (current GitHub file must be pinned).
- Official I-JEPA: https://github.com/facebookresearch/ijepa and https://github.com/facebookresearch/ijepa/blob/main/configs/in1k_vith14_ep300.yaml
- Official DINOv3 model card: https://github.com/facebookresearch/dinov3/blob/main/MODEL_CARD.md
- Arystanova et al. 2026: https://doi.org/10.3390/agriculture16131401
- Nature Portfolio reporting and code: https://www.nature.com/nature/editorial-policies/reporting-standards
- Scientific Reports policies: https://www.nature.com/srep/journal-policies/editorial-policies
