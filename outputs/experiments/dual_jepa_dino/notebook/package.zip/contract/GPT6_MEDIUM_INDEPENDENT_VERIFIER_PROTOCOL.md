# INDEPENDENT ARCHITECTURE VERIFICATION PROTOCOL

**Reviewer:** user-designated independent verifier **GPT-6 with Medium reasoning** (sometimes called "Luna" by the user).  
**Authority:** read-only audit, no Kaggle training launches, no GitHub pushes, no silent code edits.  
**Source of truth:** `CODEX_IMPLEMENTATION_CONTRACT.md`, contract `DUAL-JEPA-DINO-2026-10-09-r1`, together with the uploaded v20 notebook and the independently pinned official Meta references.  
**Audit objective:** DETECT ANY ARCHITECTURAL, OBJECTIVE, DATA-LINEAGE, WEIGHT-LOADING, TRAINABILITY, METRIC OR EXECUTION DEVIATION before and after the final GPU run. A successful smoke test or high R² is **not** proof of faithful architecture.

## 0. Instructions to the verifier (copy into your independent chat)

> You are the independent GPT-6 Medium verifier. DO NOT implement new functionality, run Kaggle experiments, edit Codex files, or approve based on prose. You must inspect the actual generated notebook, the actual embedded package code, the final implementation's source files, the pinned config, the source model/checkpoint provenance and actual execution manifests. Diff them to `CODEX_IMPLEMENTATION_CONTRACT.md`. For each critical claim provide **evidence: file path, function, line range or exact code snippet, and a locally reproducible assertion/test**. Actively search for semantic shortcuts that could yield valid shapes or plausible scores despite violating the hypothesis. Mark each criterion PASS, FAIL, or UNVERIFIED. UNVERIFIED is never PASS. Do not authorize launch if any critical item is FAIL/UNVERIFIED. Give corrective instructions, then review the corrected files in a second pass. For completed runs, recompute metrics independently from raw OOF predictions and verify source+checkpoint hashes. You are verifying fidelity and validity, not aesthetic coding style or whether results improved.

### Materials required BEFORE review

Require Codex to supply exact artifacts:

1. The ORIGINAL `capstone_v20.ipynb` and its SHA256, the new generated self-contained `.ipynb`, and the unpacked code matching its actual embedded ZIP bytes.
2. Current Git SHA/dirty diff; exact all source modules and tests; `CONFIG_LOCK.json`, `source_manifest.json`, offline weights metadata and hashes; actual Stage1 I-JEPA saved source. If actual weight bytes are unavailable, mark checkpoint-integrity items UNVERIFIED.
3. Fold CSV, image/target audit, original-source ID→parent-permutation manifest, data-leakage report; no raw private images need be copied outside authorized environment to verify hashes.
4. Actual synthetic unit-test logs, genuine GPU smoke logs with parameter delta information and tensor shapes, resource feasibility measurements, selected/resumable checkpoint manifests.
5. After execution: full fold-wise predictions/targets, heads+predictor checkpoints, independent model reload samples, per-step/per-epoch logs, figures' numeric inputs, complete `STATUS.json` and file hashes.

Never confuse notebook source with executed version. Inspect *the exact notebook version Kaggle executed*, not just a locally prepared copy.

## 1. Audit verdict definitions

- **PASS** = inspected executable source **and** directly observed assertions or independent recreation supporting requirement; not merely Codex's written explanation.
- **FAIL** = implementation contradicts contract, tests demonstrate mismatch, or a stated experiment/score is mislabeled.
- **UNVERIFIED** = missing source/weight/actual GPU evidence, missing test, or inconclusive trace; not a negative finding but **blocks final approval**.
- **NONBLOCKING DISCLOSURE** = hypothesis risk or design limitation explicitly not required to be numerically favorable (e.g., jigsaw seams, one seed).

Critical gate statuses are reviewed in **two phases**: P0 static/tiny/GPU smoke before the long run, P1 actual checkpoints+metrics+plots afterward. A P0 PASS does not imply completed study.

## 2. Architecture and training invariants — P0 STATIC REVIEW

| ID | Requirement / trap to catch | Independent evidence/test | Fail condition |
|---|---|---|---|
| V00 | Git/revision/source lock | Recompute SHA256 of original/new notebook and embedded package, compare code in unpacked ZIP with Git diff and lock file | Notebook executes different code than reviewed |
| V01 | **Correct I-JEPA model family** | Inspect official `vit_huge(img_size=224,patch_size=14)`, encoder dim 1280, predictor depth12 width384; strict source load | DINOv3 or random ViT substituted for pretrained JEPA |
| V02 | **Stage1 30K is reused, not rerun** | Read adapted checkpoint state+metadata: encoder/predictor/target_encoder, step2400, status `completed_steps`; inspect notebook cells for invocation reachability | Notebook reruns SSL Stage1, loads foundation instead of adapted, or skips missing EMA |
| V03 | Model module/trainability identity | Introspect named trainable params by stage; inspect optimizer param IDs and `no_grad` scope; require predictor-only Stage2 | Student/teacher updated, or predictor not updated, or predictor under `no_grad` |
| V04 | **Official JEPA student masked before attention** | Instrument `OfficialEncoder.forward(images,masks)` called with actual mask list; compare reference `ssl_latents` and `apply_masks` | Full-image student tokens computed then masked after self-attention (target leakage) |
| V05 | **Teacher target + ordering** | Teacher full image, `F.layer_norm` token vectors, target masks, reference `repeat_interleave_batch` ordering; compare sentinel tokens for B=2 and four masks | Wrong teacher normalization, mask/target alignment or target position mapping |
| V06 | Mask geometry correct in J2 | Inspect `StrictOfficialCollator`: one context, four targets, target 15–20% sampled mask scales, no context-target intersection, valid length | Half-mask, MAE random patches or overlapping context/target silently replaces official masks |
| V07 | Jigsaw is exactly native 10×10 and within parent | On synthetic unique 1000×1000 RGB image verify bijective 100-cell mapping, 10 distinct variants/view, pixel histogram conservation before resize; audit parent IDs | Cross-image mixing, crop/discard, synthetic labels counted as originals, identical variants, shuffle after resize |
| V08 | **Validation-safe Stage2** | For each f, intersect all J2 parent IDs/variant ancestry with fold-f val IDs and group IDs; must be empty; scan cached images/latent lists | Held-out original or variant enters J2 even without biomass label |
| V09 | Paired J2 exposure schedule | Diff arms' parent IDs, slot counts, effective batch/update count, **precomputed matching actual mask arrays (not just equal RNG seed claims)** and starting predictor checkpoint hash; B has 10 original + 10 shuffles, A 20 originals per view | Unequal updates, parent distributions, differently initialized predictor, silently dropped variants |
| V10 | **J2 optimizer truly updates predictor** | Two-step GPU check with nonzero finite predictor gradients and pre/post parameter delta; bitwise student/teacher params AND buffers same | Frozen predictor or changing encoders/EMA |
| V11 | J3 uses specialized predictor and **new** four-block semantic readout | Instrument checkpoint digest J2→J3; inspect call stack; assert `complementary_patch_masks` is NEVER called | J3 silently uses Stage1 weights, original encoder-only features, or half-mask readout |
| V12 | J3 fixed mask token geometry and ordering | Require four 6×7 masks at stipulated rows/cols, 42 tokens each, context 88, no intersection; sentinel test target-major/batch-minor layout `[4,B*views,42,1280]`, then correct 4-mask/42-token pooling | Wrong target indices, token order, all-mask averaging without correct reshape |
| V13 | J biomass head and objective | Source-check 1280 in, `[B,2,1280]`, 3 nonnegative primitives, derived GDM/Total, weighted raw 5-target loss normalized with **train-only** scale, 200 epochs/final40 SWA | Old v20 log-Huber/aux CE, independent 5-targets, wrong evaluation-time target statistics, best-val epoch called selected |
| V14 | **Correct DINOv3 identity and preprocessing** | Verify official ViT-B/16 pretrained weight hash, dim768, patch16, two separate 512 RGB views, exact preprocessing, normalizers | Generic ViT/timm random backbone or I-JEPA checkpoint passed off as DINOv3 |
| V15 | **CLS/register tokens excluded** | DINO 512 feature extraction strictly `[B*2,1024,768]` patch tokens; assert 32×32 spatial order with sentinel test; cache `[B,2,8,8,768]` | CLS/reg tokens reshaped as spatial positions or wrong patch grid |
| V16 | D0/D1/D2 exactly different specified hypotheses | Review heads and equations; D0 global head, D1 nonnegative 128-cell contributions, D2 *same parameters* as D1 with coarser 4×4 pre-MLP pooled features; only D2 adds λ=0.10 consistency; D2 final inference = D1's 8×8 path | D2 architecture larger, different output on extra path, changed inference fusion, fake “scale consistency” |
| V17 | **D2 penalty nondegenerate** | On heterogenous synthetic `[B,2,8,8,768]`, penalty >1e-8 and gradient from penalty to head params nonzero; D1/D2 initial weights equal | Coarse/fine predictions algebraically identical due linearity; λ effectively 0; penalty detached |
| V18 | Image-level labels for DINO | Check D1/D2 loss calculated after area aggregation of 128 cells/32 cells, only against whole-image label, not against each local cell | Treat every cell/view as an independently labeled field |
| V19 | Match D1 versus D2 rigorously | Compare source/feature hashes, same cached images, same train-val parent sets, training steps/seed/schedule/weights; D2 differs by consistency only | Different DINO training exposures or head capacities confound effect |
| V20 | True metric | Independent metric parser/scorer uses ONE global weighted mean and target weights `.1/.1/.1/.2/.5`; synthetic known-case parity vs project scorer | Averaging fold R², per-target R², log1p R², or using arbitrary normalization |
| V21 | Checkpoint + resume + outputs | Save/load predictor, head and RNG/optim states; atomic manifests; unaltered existing outputs; save/reload parity; complete/incomplete states | Missing predictor checkpoint, unusable offline inference, partial result named complete |
| V22 | Real Kaggle viability | Inspect actual notebook cells, kernel metadata, mounted inputs, package imports, installed deps, current quota and valid output destination; two full-path GPU smoke iterations | Unavailable flags/packages, unmounted DINO checkpoint, stale quota, false ready-to-run |

### Explicit refusal triggers

Reject P0 when the new notebook relies on CLI options not implemented in its *embedded* source; when file/module names in the contract are absent without equivalent reviewed logic; when a frozen cache is substituted for predictor specialization; when Stage2 Stage1 adapted checkpoint lacks EMA teacher; when the DINO iBOT head is claimed to have been trained; or when 10 shuffles are reported as 10× independent biological subjects.

## 3. Required tests with independent oracles (P0)

**T1 — Native pixel permutation:** Create 1000² RGB input whose each 100² block contains its own unique constant coded RGB value; confirm output has the identical set and counts of coded blocks and a truly nontrivial permutation, and ten variant permutations differ. No image labels used. For strict all-pixel conservation use a second random RGB image and compare sorted RGB triplets before resize.

**T2 — Fold leakage:** Construct synthetic parents assigned fold0 and fold1 and derivatives assigned their parent's original image ID. Deliberately inject one held-out variant into training; verification MUST raise. Also assert `Sampling_Date` groups never cross folds. Check original unlabeled Stage1 manifests for exact-hash overlaps; unresolved near duplicates are disclosed.

**T3 — JEPA masked attention:** Use tiny official reference encoder with an all-unique patch sentinel. Run with correct masks, check returned number/context identities. Add a negative-control implementation that encodes full image before token filtering and verify the test detects difference; correct source must not leak full-image attention. The test may instrument code path if mathematical outputs depend on initialization.

**T4 — JEPA mask→teacher/predictor ordering:** For batch 2 and four masks with distinct explicit indices, set synthetic teacher-token vectors with unique mask/position codes, feed reference `apply_masks`/`repeat_interleave_batch`, and demonstrate J3 prediction pooling respects batch and target-mask dimensions. A shape check alone is insufficient.

**T5 — Stage2 gradients and immutability:** Run 2 optimizer steps in actual GPU precision mode. Hash state dict (both params and buffers) of frozen student+teacher before and after; require identical. Confirm actual `max_abs_update(predictor)>0`; optimizer contains only predictor IDs; check numerical finiteness and actual counted steps.

**T6 — Stage3 reload:** Before and after predictor specialization, run identical unshuffled input/masks. Confirm J3 loads the *after* weights by exact digest and that stage2 predictor feature embeddings change for at least one input; full head save/reload must reproduce predictions to declared precision tolerance. If specialized predictor embeddings do not change, investigate before launch.

**T7 — DINO token family:** Compare model metadata and actual `forward_features` keys to official DINO release; assert 1024 patch tokens after 512 input and no inclusion of special tokens. For a dummy known spatial feature grid, verify region-grid pooling geometry 32²→8²→4² and equal image coverage of both complete views.

**T8 — DINO no-spatial pseudo-label:** Set one full-field target for synthetic two-view image. Verify D1 `loss` has one term per ORIGINAL image, not one per region; output must be `[B,5]`, primitive contributions are nonnegative, total predicted mass is area-averaged.

**T9 — DINO consistency nondegeneracy:** Initialize nonlinear density MLP with deterministic nonzero nonconstant weights and heterogeneous synthetic embeddings. Show `pred_4 != pred_8`, consistency loss >1e-8, consistency-only backward gives nonzero gradient to density MLP. Prove D1 and D2 have equal trainable parameter counts and identical primary inference function.

**T10 — R² independent parity:** Fabricate small N×5 dataset with asymmetric target means; independently calculate scalar/global R². Test project `metrics.scores` matches; test a WRONG mean-of-five R² implementation yields a different value, proving the test discriminates errors.

**T11 — Initial zero-head gradients:** Because current `GatedRegressionHead` starts with zero last-layer weights, do not require encoder/head-hidden gradients on backward #1. After first head update, verify deeper head gradients finite and may be nonzero. This is an expected transient, not proof of bad code.

**T12 — End-to-end smoke:** Run synthetic CPU tiny tests AND real GPU 1–2 training iterations from each J and D branch with actual checkpoint source in a `_smoke` folder. Verify snapshot hashes, no contamination of final directories and fresh resource-cost measurement.

## 4. After-run independent evidence and numerical review (P1)

1. **Source/execution match:** obtain the actual Kaggle notebook version the GPU executed and its package archive hash. Compare with P0 reviewed version. Any changed bytes affecting model/training require fresh review.
2. **Checkpoint lineage:** `Stage1 adapted.pt SHA` → `Stage2 per fold/arm initial predictor SHA` → `Stage2 final predictor SHA` → `Stage3 loaded predictor SHA` → `Stage3 selected regression head SHA`; DINO source hash → DINO cached feature signature → D0/D1/D2 head checkpoint hashes. Require `strict=True` state loads and no missing/unexpected keys.
3. **Number of genuine individuals:** each model's two-fold OOF must comprise exactly 105 original CSIRO photographs with identical IDs/labels/folds; not 1,050 jigsaw variants. Confirm each original appears once, no duplicates, all prediction values finite and nonnegative.
4. **Objective and resource adherence:** compare actual completed optimizer steps, effective batch, head epochs, SWA counts, learning rates, frozen parameter updates (or absence), precision and runtime logs to the locked config; independently compute temporal quantities. NO claim complete based only on saved source or GPU model label.
5. **Independent metrics:** use fresh no-project-import standard Python or NumPy code to read raw OOF and calculate pooled weighted R², five target R²/MAE/RMSE, date counts, pairwise score differences and date-block bootstrap with fixed seed. Require max difference <1e-8 from CSV-rescored reported values (allow serialization rounding; require FP64 recheck of printed CSVs).
6. **Bootstrap:** exact date-group paired resample, same sampled groups for both arms, with replacement preserving group multiplicity; percentile 95% CI on score **delta**, not overlap of individual-model CIs. Record invalid denominator replicates and effective draws. Note 9 reused date groups/one seed means no clean independent generalization inference.
7. **Plot provenance:** every figure must map to saved CSV or approved source original image. Verify example shuffle permutation arrays and no Photoshop-like edits, no invented smooth curves, and DINO heatmaps called **unvalidated learned contribution proxies**, not measured local biomass.
8. **Paper truthfulness:** independent scientific auditor verifies H1/H2/H3 scope, historical scores not used as matched new controls, DINO/iBOT not mischaracterized, no novelty guarantee, and documented original JEPA/dense-tiling prior art, data/code/weight redistribution licenses and SciRep availability statements.

## 5. Report format: RETURN EXACTLY THESE ARTIFACTS

**`ARCHITECTURE_VERDICT.md`**, containing:

```
Contract ID: DUAL-JEPA-DINO-2026-10-09-r1
Review phase: P0 / P1 / BOTH
Reviewed source commit + notebook source hash + Kaggle executed version/hash (if P1): ...
Overall verdict: PASS / FAIL / UNVERIFIED
Blocking failures (by Vxx): ...
Unverified required evidence: ...
Allowed nonblocking limitations: ...
Matrix: ID | PASS/FAIL/UNVERIFIED | actual code path+line | independent evidence | corrective action
Architectural deviations discovered (including seemingly "helpful" changes): ...
Source vs notebook embedded-package parity: PASS/FAIL/UNVERIFIED
Frozen weights, actual updated predictor, DINO special-token handling: ...
Controls and hypothesis-identifiability: ...
Metric and pairing check: ...
Figure integrity and manuscript claim validity: ...
Decision: DO_NOT_RUN / READY_FOR_GPU / RUN_FINISHED_NOT_VALIDATED / VALIDATED_EXPLORATORY
```

**`VERIFICATION_MATRIX.csv`**, columns: `id,requirement,severity,status,source_path,source_line_or_function,test_command,evidence_path,remediation`.

**`REPRODUCIBILITY_CHECKS.json`**: static source hashes, tested tensor shapes, actual before/after predictor+student+EMA hashes, official mask and leak tests, DINO nondegenerate penalty value/grad, source→checkpoint load map, metric parity error, executed notebook identity, and unresolved uncertainties.

No numerical result can be called independently verified unless P1 evidence is available. A P0 architecture PASS means code is eligible for GPU launch (subject to actual GPU/quota), not that a trial worked scientifically.

## 6. Independent verifier's priority order (use under deadline)

Check **first**: (1) Stage1 checkpoint truly exists; (2) Stage2 ONLY predictor learns; (3) no fold val images in Stage2; (4) Stage3 really reads the specialized predictor, NOT old half masks; (5) DINO truly ViT-B and excludes register tokens; (6) D2 consistency is nontrivial; (7) primary loss, target labels and paired metric correct; (8) executable notebook embeds actual tested modules and offline weights; (9) compute feasibility and output checkpoint integrity. If any of these fails, flag a **critical blocker immediately** rather than spending review time on plots.

### Source authorities

- `CODEX_IMPLEMENTATION_CONTRACT.md` (**locked local requirement source**)
- Original uploaded v20 embedded reference I-JEPA code (`official_ijepa.py`, `official_train.py`, `ijepa_reference/multiblock.py`)
- Current repository `biomass_jepa/official_heads.py` (must pin actual commit)
- https://github.com/facebookresearch/ijepa/blob/main/configs/in1k_vith14_ep300.yaml
- https://github.com/facebookresearch/ijepa/blob/main/src/train.py
- https://github.com/facebookresearch/dinov3/blob/main/MODEL_CARD.md
- https://doi.org/10.3390/agriculture16131401
- https://www.nature.com/srep/journal-policies/editorial-policies
