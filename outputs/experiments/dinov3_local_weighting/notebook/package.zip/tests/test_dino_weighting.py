import torch
from biomass_jepa.dino_weighting import make_head, head_loss


def test_uniform_start_and_matched_rng_density():
    torch.set_num_threads(2)
    torch.manual_seed(42); a=make_head('D1',20.); after_a=torch.get_rng_state()
    torch.manual_seed(42); b=make_head('D3',20.); after_b=torch.get_rng_state()
    assert torch.equal(after_a,after_b)
    for k,v in a.density_head.state_dict().items():
        assert torch.equal(v,b.density_head.state_dict()[k])
    x=torch.randn(3,2,8,8,768)
    w=b.pooling_weights(x)
    assert torch.allclose(w.sum((1,2,3)),torch.ones(3,3))
    assert torch.allclose(a(x),b(x),rtol=1e-6,atol=1e-5)


def test_weight_gradients_and_whole_image_sums():
    torch.manual_seed(3); b=make_head('D3',20.)
    x=torch.randn(3,2,8,8,768); y=torch.rand(3,5)*100
    loss,_=head_loss(b,x,y,'D3'); loss.backward()
    assert b.weight_head[-1].weight.grad.abs().max()>0
    optimizer=torch.optim.AdamW(b.parameters(),lr=3e-4); optimizer.step()
    optimizer.zero_grad(); head_loss(b,x,y,'D3')[0].backward()
    assert b.weight_head[0].weight.grad.abs().max()>0
    p=b(x)
    assert torch.all(p>=0)
    assert torch.allclose(p[:,3],p[:,0]+p[:,2])
    assert torch.allclose(p[:,4],p[:,3]+p[:,1])


def test_cell_order_invariance_and_serialization():
    torch.manual_seed(11); b=make_head('D3',20.)
    torch.nn.init.normal_(b.weight_head[-1].weight,std=.1)
    x=torch.randn(2,2,8,8,768); perm=torch.randperm(128)
    xp=x.reshape(2,128,768)[:,perm].reshape_as(x)
    assert torch.allclose(b(x),b(xp),atol=1e-4,rtol=1e-5)
    c=make_head('D3',20.); c.load_state_dict(b.state_dict(),strict=True)
    assert torch.equal(b(x),c(x))


def test_training_resume_and_fixed_swa(tmp_path):
    import pandas as pd
    from biomass_jepa.final_head import fit_cached_head
    torch.set_num_threads(2);torch.manual_seed(4)
    frame=pd.DataFrame({'image_path':[f'i{i}' for i in range(6)],'fold':[0,0,1,1,1,1],'Sampling_Date':['v','v','t','t','t','t']})
    y=torch.rand(6,3)*40
    names=['Dry_Green_g','Dry_Dead_g','Dry_Clover_g','GDM_g','Dry_Total_g']
    y=torch.cat([y,(y[:,0]+y[:,2])[:,None],y.sum(1)[:,None]],1)
    for j,n in enumerate(names):frame[n]=y[:,j].numpy()
    x=torch.randn(6,2,8,8,768)
    options=dict(epochs=4,swa_last=2,batch_size=2,head_factory=make_head,loss_function=head_loss)
    a=fit_cached_head(frame,x,0,'D3',tmp_path/'full',{'test':'resume'},**options)
    fit_cached_head(frame,x,0,'D3',tmp_path/'resume',{'test':'resume'},stop_after_updates=3,**options)
    b=fit_cached_head(frame,x,0,'D3',tmp_path/'resume',{'test':'resume'},**options)
    assert a['completed_epochs']==b['completed_epochs']==4
    assert a['swa_count']==b['swa_count']==2
    assert a['global_weighted_r2_raw']==b['global_weighted_r2_raw']
    first=torch.load(tmp_path/'full/head_selected.pt',weights_only=True)['model']
    second=torch.load(tmp_path/'resume/head_selected.pt',weights_only=True)['model']
    assert all(torch.equal(first[k],second[k]) for k in first)
